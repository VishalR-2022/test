var crypto = require("crypto");
module.exports = crypto;